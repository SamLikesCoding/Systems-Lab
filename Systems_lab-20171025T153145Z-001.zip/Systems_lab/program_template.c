/*

	Write Title Here!
	Created by : Sarath Peter
	Status : Write Status Here!
*/

#include<stdio.h>
#include<stdlib.h>



int main()
{
  system("clear");
}
