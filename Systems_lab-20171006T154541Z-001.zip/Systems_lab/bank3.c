/*

	Bankers Algotrithm
	Created by : Sarath Peter
	
*/

#include<stdio.h>
#include<stdlib.h>

int main()
{
  int i,j,n,p,a[i],max[10][10],alloc[10][10],need[10][10];

  system("clear");
  printf("\n Enter no of Resources : ");
  scanf("%d",&n);
  printf("\n Enter Number of Processes : ");
  scanf("%d",&p);
  
  for(i=0;i<n;i++)
  {
   	printf("\nHow much available for resource %c : ",(i+97));	
  	scanf("%d",&a[i]);
  } 
  
  printf("\n Enter Max Values : ");
  for(i=0;i<n;i++)
  {
  	for(j=0;j<m;j++)
  	{
  		printf("Index(%d,%d):",i,j);
  		scanf("%d",&max[i][j]);
  	}
  }
  
  printf("\n Enter Allocation Values : ")
  for(i=0;i<n;i++)
  {
  	for(j=0;j<m;j++)
  	{
  		printf("Index(%d,%d):",i,j);
  		scanf("%d",&alloc[i][j]);
  	}
  }
  
  for(i=0;i<n;i++)
  {
  	for(j=0;j<m;j++)
  	{
  		if(max[i][j]>=alloc[i][j])
  		{
  		 need[i][j]=max[i][j]-alloc[i][j];
  		}
  	}
  }
  
  
  
}
